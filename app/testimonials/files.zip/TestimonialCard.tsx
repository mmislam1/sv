import Image from "next/image";

export interface Testimonial {
  id: number;
  title: string;
  review: string;
  author: string;
  role: string;
  avatar: string;
  rating: number;
  maxRating?: number;
}

interface TestimonialCardProps {
  testimonial: Testimonial;
}

export default function TestimonialCard({ testimonial }: TestimonialCardProps) {
  const { title, review, author, role, avatar, rating, maxRating = 5 } = testimonial;

  const renderStars = (rating: number, max: number) => {
    return Array.from({ length: max }, (_, i) => {
      const filled = i < Math.floor(rating);
      const partial = !filled && i < rating;
      return (
        <span key={i} className="relative inline-block text-sm leading-none">
          <span className="text-gray-600">★</span>
          {(filled || partial) && (
            <span
              className="absolute inset-0 text-yellow-400 overflow-hidden"
              style={{ width: filled ? "100%" : `${(rating % 1) * 100}%` }}
            >
              ★
            </span>
          )}
        </span>
      );
    });
  };

  return (
    <article className="group flex flex-col justify-between bg-[#1a1a1a] rounded-2xl p-5 sm:p-6 shadow-md hover:shadow-xl hover:-translate-y-1 transition-all duration-300 h-full">
      {/* Content */}
      <div className="flex flex-col gap-3">
        <h3 className="text-white font-bold text-base sm:text-lg leading-snug">
          {title}
        </h3>
        <p className="text-gray-400 text-sm leading-relaxed line-clamp-4">
          {review}
        </p>
      </div>

      {/* Author row */}
      <div className="flex items-center justify-between mt-5 gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="relative w-10 h-10 rounded-full overflow-hidden flex-shrink-0 ring-2 ring-gray-700">
            <Image
              src={avatar}
              alt={author}
              fill
              sizes="40px"
              className="object-cover"
            />
          </div>
          <div className="min-w-0">
            <p className="text-white text-sm font-semibold leading-tight truncate">
              {author}
            </p>
            <p className="text-gray-500 text-xs leading-tight truncate">{role}</p>
          </div>
        </div>

        {/* Stars + rating */}
        <div
          className="flex items-center gap-1 flex-shrink-0"
          aria-label={`Rating: ${rating} out of ${maxRating}`}
        >
          <div className="flex items-center">
            {renderStars(rating, maxRating)}
          </div>
          <span className="text-gray-400 text-xs ml-1">({rating.toFixed(1)})</span>
        </div>
      </div>
    </article>
  );
}

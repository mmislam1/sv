"use client";

import TestimonialCard, { Testimonial } from "@/components/TestimonialCard";

// ── Static data ─────────────────────────────────────────────────────────────
// Replace with an API/CMS fetch as needed. Avatar paths live in /public/avatars/
const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    title: "The Best Training Program!",
    review:
      "The boxing program helped me build confidence, strength, and endurance. The coaches are supportive and push you to be your best. Highly recommend for anyone serious about their fitness!",
    author: "Steve Meloni",
    role: "CEO of Miko",
    avatar: "/avatars/steve-1.jpg",
    rating: 4.9,
  },
  {
    id: 2,
    title: "The Best Training Program!",
    review:
      "The boxing program helped me build confidence, strength, and endurance. The coaches are supportive and push you to be your best. Highly recommend for anyone serious about their fitness!",
    author: "Steve Meloni",
    role: "CEO of Miko",
    avatar: "/avatars/steve-2.jpg",
    rating: 4.9,
  },
  {
    id: 3,
    title: "The Best Training Program!",
    review:
      "The boxing program helped me build confidence, strength, and endurance. The coaches are supportive and push you to be your best. Highly recommend for anyone serious about their fitness!",
    author: "Steve Meloni",
    role: "CEO of Miko",
    avatar: "/avatars/steve-3.jpg",
    rating: 4.8,
  },
  {
    id: 4,
    title: "The Best Training Program!",
    review:
      "The boxing program helped me build confidence, strength, and endurance. The coaches are supportive and push you to be your best. Highly recommend for anyone serious about their fitness!",
    author: "Steve Meloni",
    role: "CEO of Miko",
    avatar: "/avatars/steve-4.jpg",
    rating: 4.9,
  },
  {
    id: 5,
    title: "The Best Training Program!",
    review:
      "The boxing program helped me build confidence, strength, and endurance. The coaches are supportive and push you to be your best. Highly recommend for anyone serious about their fitness!",
    author: "Steve Meloni",
    role: "CEO of Miko",
    avatar: "/avatars/steve-5.jpg",
    rating: 4.9,
  },
  {
    id: 6,
    title: "The Best Training Program!",
    review:
      "The boxing program helped me build confidence, strength, and endurance. The coaches are supportive and push you to be your best. Highly recommend for anyone serious about their fitness!",
    author: "Steve Meloni",
    role: "CEO of Miko",
    avatar: "/avatars/steve-6.jpg",
    rating: 4.8,
  },
];

// ── Component ────────────────────────────────────────────────────────────────
export default function TestimonialsSection() {
  return (
    <section className="bg-[#f0f0f0] py-10 px-4 sm:px-6 lg:px-12">
      {/* ── Section header ── */}
      <div className="flex items-start justify-between mb-6 sm:mb-8">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-gray-900 leading-tight">
            What Our Clients Are Saying
          </h2>
          <p className="mt-1 text-sm sm:text-base text-gray-500">
            Real Stories, Real Results — Hear From Our Athletes
          </p>
        </div>

        {/* Decorative arrow cluster */}
        <div
          className="hidden sm:flex items-center gap-1 opacity-30 pt-1 flex-shrink-0"
          aria-hidden="true"
        >
          {["▲", "▲", "▲"].map((a, i) => (
            <span key={i} className="text-gray-400 text-xs rotate-90 select-none">
              {a}
            </span>
          ))}
        </div>
      </div>

      {/* ── Testimonials grid ── */}
      <div
        className="
          grid gap-4
          grid-cols-1
          sm:grid-cols-2
          lg:grid-cols-3
        "
      >
        {TESTIMONIALS.map((testimonial) => (
          <TestimonialCard key={testimonial.id} testimonial={testimonial} />
        ))}
      </div>
    </section>
  );
}
